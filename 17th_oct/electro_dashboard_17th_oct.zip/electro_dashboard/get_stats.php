<?php
require "db.php";
$row = $pdo->query("SELECT * FROM stats WHERE id=1")->fetch();
echo json_encode($row);
?>
