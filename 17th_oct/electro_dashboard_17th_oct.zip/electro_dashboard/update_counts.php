<?php
require "db.php"; // your DB connection

$total_humans = intval($_GET['total_humans'] ?? 0);
$escaped_c4 = intval($_GET['escaped_c4'] ?? 0);
$escaped_c5 = intval($_GET['escaped_c5'] ?? 0);

$stmt = $pdo->prepare("UPDATE stats SET total_humans = ?, escaped_c4 = ?, escaped_c5 = ? WHERE id = 1");
$stmt->execute([$total_humans, $escaped_c4, $escaped_c5]);


echo "Counts updated";
?>
