<?php
// index.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Corridor Dashboard — Real-time Monitor</title>
<link rel="stylesheet" href="style.css">
<style>
.graph {
  margin-top: 20px;
  padding: 15px;
  border: 1px solid #ddd;
  border-radius: 8px;
  background: #fafafa;
}
.path-item {
  margin: 8px 0;
  font-weight: bold;
}
.path-item.connected {
  color: green;
}
.path-item.disconnected {
  color: red;
}
</style>
</head>
<body>
<div class="container">
<header>
<div>
<h1>Corridor Monitoring Dashboard</h1>
</div>
<div class="muted">Updated: <span id="lastUpdate">--</span></div>
</header>

<div class="topcards">
<div class="stat card">
<div class="muted">Corridors monitored</div>
<div class="big" id="totalCorridors">5</div>
</div>
<div class="stat card">
<div class="muted">High risk right now</div>
<div class="big" id="highCount">0</div>
</div>
<div class="stat card">
<div class="muted">Medium risk</div>
<div class="big" id="medCount">0</div>
</div>
</div>

<div class="grid" id="cards">
<!-- Cards inserted by JS -->

<div class="card">
  <h3>People Statistics</h3>
  <p>Total in building: <span id="totalHumans">0</span></p>
  <p>Escaped via C4 → E2: <span id="escC4">0</span></p>
  <p>Escaped via C5 → E1: <span id="escC5">0</span></p>
</div>

</div>

<!-- Graph section -->
<div class="graph">
  <h2>Escape Paths</h2>
  <div id="paths"></div>
</div>
</div>

<script>
const apiUrl = "api.php"; // endpoint
const pollInterval = 3000; // ms

function updateStats() {
  fetch("get_stats.php")
    .then(res => res.json())
    .then(data => {
      document.getElementById("totalHumans").innerText = data.total;
      document.getElementById("escC4").innerText = data.escaped_c4;
      document.getElementById("escC5").innerText = data.escaped_c5;
    });
}
setInterval(updateStats, 3000);

// Generate 5 corridor cards
function makeCards() {
    const container = document.getElementById("cards");
    for (let i = 1; i <= 5; i++) {
        container.innerHTML += `
        <div class="card" id="corridor-${i}">
          <h2>Corridor ${i}</h2>
          <div class="meta">
            <div class="id">#${i}</div>
            <div class="time" id="time-${i}">--</div>
          </div>
          <div class="values">
            <div class="value"><div class="label">Flame</div><div class="num" id="flame-${i}">--</div><div class="barwrap"><div class="bar" id="bar-flame-${i}"></div></div></div>
            <div class="value"><div class="label">Gas</div><div class="num" id="gas-${i}">--</div><div class="barwrap"><div class="bar" id="bar-gas-${i}"></div></div></div>
            <div class="value"><div class="label">Temperature</div><div class="num" id="temp-${i}">--</div></div>
            <div class="value"><div class="label">Humidity</div><div class="num" id="hum-${i}">--</div></div>
          </div>
          <div class="risk">
            <span>Risk</span>
            <span class="badge low" id="risk-${i}">--</span>
          </div>
        </div>`;
    }
}

function formatTime(str) {
    if (!str) return "--";
    return new Date(str).toLocaleTimeString();
}

function updateUI(resp) {
    const data = resp.corridors || {};
    const paths = resp.paths || {};

    let high = 0, med = 0;
    for (let i = 1; i <= 5; i++) {
        const c = data[i] || {};
        document.getElementById("flame-"+i).textContent = c.flame ?? "--";
        document.getElementById("gas-"+i).textContent = c.gas ?? "--";
        document.getElementById("temp-"+i).textContent = c.temperature ?? "--";
        document.getElementById("hum-"+i).textContent = c.humidity ?? "--";
        document.getElementById("time-"+i).textContent = formatTime(c.recorded_at);

        document.getElementById("bar-flame-"+i).style.width = c.flame ? Math.min(100, (c.flame/1023*100))+"%" : "0%";
        document.getElementById("bar-gas-"+i).style.width = c.gas ? Math.min(100, (c.gas/1023*100))+"%" : "0%";

        const riskEl = document.getElementById("risk-"+i);
        if (c.risk === "high") {
            riskEl.textContent = "HIGH";
            riskEl.className = "badge high";
            high++;
        } else if (c.risk === "medium") {
            riskEl.textContent = "MEDIUM";
            riskEl.className = "badge medium";
            med++;
        } else if (c.risk === "low") {
            riskEl.textContent = "LOW";
            riskEl.className = "badge low";
        } else {
            riskEl.textContent = "--";
            riskEl.className = "badge low";
        }
    }

    document.getElementById("lastUpdate").textContent = new Date().toLocaleTimeString();
    document.getElementById("highCount").textContent = high;
    document.getElementById("medCount").textContent = med;

    // update paths visualization
    const pathDiv = document.getElementById("paths");
    pathDiv.innerHTML = "";
    for (const [corr, info] of Object.entries(paths)) {
        const p = info.path || [];
        const connected = (p.length > 0);
        const text = connected ? p.map(n => "C"+n).join(" → ") : "No safe path";
        const cls = connected ? "connected" : "disconnected";
        const cost = info.cost ?? "--";
        pathDiv.innerHTML += `<div class="path-item ${cls}">From C${corr}: ${text} (Cost: ${cost})</div>`;
    }
}

async function poll() {
    try {
        const res = await fetch(apiUrl + "?t=" + Date.now());
        if (!res.ok) throw new Error("Network");
        const data = await res.json();
        updateUI(data);
    } catch (e) {
        console.error("poll error", e);
    } finally {
        setTimeout(poll, pollInterval);
    }
}

// init
makeCards();
poll();
</script>
</body>
</html>
