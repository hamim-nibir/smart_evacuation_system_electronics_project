<?php
// get_stats.php
header('Content-Type: application/json');
require_once 'db_config.php'; // contains $conn = new mysqli(...)

$response = [
    "total" => 0,
    "escaped_c4" => 0,
    "escaped_c5" => 0
];

// Fetch latest counts from database
$sql = "SELECT total_count, c4_escape, c5_escape 
        FROM human_counts 
        ORDER BY id DESC 
        LIMIT 1";

if ($result = $conn->query($sql)) {
    if ($row = $result->fetch_assoc()) {
        $response["total"] = (int)$row["total_count"];
        $response["escaped_c4"] = (int)$row["c4_escape"];
        $response["escaped_c5"] = (int)$row["c5_escape"];
    }
    $result->free();
}

echo json_encode($response);
$conn->close();
?>
