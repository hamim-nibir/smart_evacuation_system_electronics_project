<?php
// add_counts.php

$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'corridor_db';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['status'=>'error','msg'=>'DB connection failed']);
    exit;
}

$total = isset($_REQUEST['total']) ? intval($_REQUEST['total']) : 0;
$c4    = isset($_REQUEST['c4']) ? intval($_REQUEST['c4']) : 0;
$c5    = isset($_REQUEST['c5']) ? intval($_REQUEST['c5']) : 0;

$stmt = $conn->prepare("INSERT INTO human_counts (total_count, c4_escape, c5_escape) VALUES (?, ?, ?)");
$stmt->bind_param("iii", $total, $c4, $c5);

if ($stmt->execute()) {
    echo json_encode(['status'=>'ok', 'insert_id' => $stmt->insert_id]);
} else {
    http_response_code(500);
    echo json_encode(['status'=>'error','msg'=>$stmt->error]);
}

$stmt->close();
$conn->close();
?>
