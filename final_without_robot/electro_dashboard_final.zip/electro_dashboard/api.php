<?php
// api.php
header('Content-Type: application/json; charset=utf-8');

// DB settings (adjust to your environment)
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'corridor_db';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'DB connection failed']);
    exit;
}

$max_corridors = 5;

// Get latest row for each corridor
$sql = "
SELECT t.corridor_id, t.flame, t.gas, t.temperature, t.humidity, t.recorded_at
FROM sensor_data t
INNER JOIN (
  SELECT corridor_id, MAX(recorded_at) AS mx
  FROM sensor_data
  WHERE corridor_id BETWEEN 1 AND ?
  GROUP BY corridor_id
) latest 
ON latest.corridor_id = t.corridor_id AND latest.mx = t.recorded_at
ORDER BY t.corridor_id ASC
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['error' => 'prepare failed', 'details' => $conn->error]);
    exit;
}
$stmt->bind_param("i", $max_corridors);
$stmt->execute();
$res = $stmt->get_result();

$result = [];
$risks = [];

// initialize defaults so UI doesn't break
for ($i=1; $i <= $max_corridors; $i++) {
    $result[$i] = null;
    $risks[$i] = 10; // default medium cost (keeps paths available if a corridor hasn't reported yet)
}

// Process DB rows and classify risk (keeps thresholds consistent with your Mega logic)
while ($row = $res->fetch_assoc()) {
    $cid = intval($row['corridor_id']);
    $flame = isset($row['flame']) ? intval($row['flame']) : null;
    $gas = isset($row['gas']) ? intval($row['gas']) : null;
    $temperature = isset($row['temperature']) ? floatval($row['temperature']) : null;
    $humidity = isset($row['humidity']) ? floatval($row['humidity']) : null;
    $recorded_at = $row['recorded_at'];

    // risk logic: match your Mega thresholds
    $risk = 'low';
    $risk_cost = 5; // low

    if (($flame !== null && $flame < 400)) {
        $risk = 'high';
        $risk_cost = 15;
    } else if (($flame !== null && $flame < 800)) {
        $risk = 'medium';
        $risk_cost = 10;
    }

    $risks[$cid] = $risk_cost;

    $result[$cid] = [
        'flame' => $flame,
        'gas' => $gas,
        'temperature' => $temperature,
        'humidity' => $humidity,
        'recorded_at' => $recorded_at,
        'risk' => $risk
    ];
}

$stmt->close();
$conn->close();

// -------- PATHFINDING --------
// Graph structure (corridors + exits as nodes)
// Keep this topology as you had it
$graph = [
  1 => [2],
  2 => [1,3,4],
  3 => [2,5],
  4 => [2], // Exit 2
  5 => [3], // Exit 1
];
$exits = [4,5];

/**
 * Simple Dijkstra (no early exit). Node costs are stored in $risks.
 * We treat the cost to "move" into a neighbor v as the neighbor's node cost.
 */
function dijkstra($graph, $risks, $start, $exits) {
    $dist = [];
    $prev = [];
    $Q = [];

    // initialize
    foreach ($graph as $node => $edges) {
        $dist[$node] = INF;
        $prev[$node] = null;
        $Q[$node] = true;
    }
    $dist[$start] = 0;

    // main loop WITHOUT breaking when first exit is popped
    while (!empty($Q)) {
        // find node u in Q with smallest dist
        $u = null;
        foreach ($Q as $node => $_) {
            if ($u === null || $dist[$node] < $dist[$u]) {
                $u = $node;
            }
        }
        // if unreachable nodes remain, we're done
        if ($u === null || $dist[$u] === INF) break;

        // mark u as visited (remove from Q)
        unset($Q[$u]);

        // relax neighbors
        if (isset($graph[$u])) {
            foreach ($graph[$u] as $v) {
                // only consider neighbors still in Q
                if (!isset($Q[$v])) continue;
                $alt = $dist[$u] + ($risks[$v] ?? 10);
                if ($alt < $dist[$v]) {
                    $dist[$v] = $alt;
                    $prev[$v] = $u;
                }
            }
        }
    }

    // choose nearest reachable exit (if any)
    $nearestExit = null;
    $minDist = INF;
    foreach ($exits as $e) {
        if (isset($dist[$e]) && $dist[$e] < $minDist) {
            $minDist = $dist[$e];
            $nearestExit = $e;
        }
    }

    // reconstruct path (start..exit) if reachable
    $path = [];
    if ($nearestExit !== null && $minDist < INF) {
        for ($at = $nearestExit; $at !== null; $at = $prev[$at]) {
            array_unshift($path, $at);
        }
    }

    return [
        "from" => $start,
        "exit" => $nearestExit,
        "cost" => ($minDist === INF ? null : $minDist),
        "path" => $path
    ];
}

// Compute safest path for corridors 1..3 (non-exit starting points)
$paths = [];
foreach ([1,2,3] as $c) {
    $paths[$c] = dijkstra($graph, $risks, $c, $exits);
}

// Final response
$response = [
    "corridors" => $result,
    "paths" => $paths
];

echo json_encode($response, JSON_PRETTY_PRINT);
